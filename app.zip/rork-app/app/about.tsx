import React from 'react';
import { StyleSheet, View, Platform, StatusBar } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import CustomHeader from '@/components/CustomHeader';
import AboutSection from '@/components/AboutSection';
import { useTheme } from '@/contexts/ThemeContext';

export default function AboutScreen() {
  const { type = 'about' } = useLocalSearchParams<{ type: string }>();
  const { theme } = useTheme();
  
  // Validate type parameter
  const validType = ['about', 'privacy', 'terms'].includes(type) 
    ? type as 'about' | 'privacy' | 'terms' 
    : 'about';
  
  // Get title based on type
  const getTitle = () => {
    switch (validType) {
      case 'about':
        return 'About Meditate';
      case 'privacy':
        return 'Privacy Policy';
      case 'terms':
        return 'Terms of Service';
      default:
        return 'About';
    }
  };

  // Calculate bottom padding to avoid tab bar overlap
  const bottomPadding = Platform.OS === 'ios' ? 88 : 60;

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <CustomHeader 
        title={getTitle()} 
        showBackButton={true}
      />
      
      <View style={[styles.content, { paddingBottom: bottomPadding }]}>
        <AboutSection type={validType} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  }
});