import React from 'react';
import { StyleSheet, Text, View, Pressable, Platform, StatusBar } from "react-native";
import { useRouter } from 'expo-router';
import { X } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

export default function ModalScreen() {
  const router = useRouter();
  const { theme } = useTheme();
  
  // Calculate status bar height for proper spacing
  const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 44 : StatusBar.currentHeight || 0;

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      {/* Status bar with light content for modal */}
      <StatusBar barStyle="light-content" />
      
      <View style={[styles.header, { paddingTop: STATUSBAR_HEIGHT }]}>
        <Text style={[styles.title, { color: theme.text }]}>Modal</Text>
        <Pressable 
          style={({ pressed }) => [
            styles.closeButton,
            { 
              backgroundColor: theme.lightGray,
              borderColor: theme.border,
            },
            pressed && styles.buttonPressed
          ]}
          onPress={() => router.back()}
        >
          <X size={24} color={theme.text} />
        </Pressable>
      </View>
      
      <View style={styles.content}>
        <Text style={{ color: theme.text }}>This is an example modal. You can edit it in app/modal.tsx.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: 60 + (Platform.OS === 'ios' ? 44 : StatusBar.currentHeight || 0),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
  },
  closeButton: {
    position: 'absolute',
    right: 16,
    bottom: 10,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
  buttonPressed: {
    opacity: 0.7,
  },
  content: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
});