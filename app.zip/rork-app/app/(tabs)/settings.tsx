import React, { useState } from 'react';
import { StyleSheet, Text, View, ScrollView, SafeAreaView, Pressable, Switch, Alert, Platform, Modal, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Bell, Moon, Volume2, Trash2, Info, ChevronRight, Clock } from 'lucide-react-native';
import useStore from '@/store/meditation-store';
import useSettingsStore from '@/store/settings-store';
import CustomHeader from '@/components/CustomHeader';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';
import TimePicker from '@/components/TimePicker';

export default function SettingsScreen() {
  const router = useRouter();
  const { clearAllData } = useStore();
  const { settings, updateSettings, toggleNotifications, toggleDarkMode, reminderTime, setReminderTime } = useSettingsStore();
  const { theme, isDark } = useTheme();
  
  const [timePickerVisible, setTimePickerVisible] = useState(false);
  
  const handleClearData = () => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }
    
    Alert.alert(
      "Clear All Data",
      "Are you sure you want to clear all your meditation data? This action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Clear Data", 
          style: "destructive",
          onPress: () => {
            clearAllData();
            Alert.alert("Data Cleared", "All your meditation data has been cleared.");
          }
        }
      ]
    );
  };

  const navigateToAbout = (type: 'about' | 'privacy' | 'terms') => {
    router.push(`/about?type=${type}`);
  };
  
  const formatTime = (hour: number, minute: number) => {
    const period = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 === 0 ? 12 : hour % 12;
    return `${displayHour}:${minute.toString().padStart(2, '0')} ${period}`;
  };
  
  const handleTimeSelected = (hour: number, minute: number) => {
    setReminderTime(hour, minute);
    setTimePickerVisible(false);
    
    // If notifications are enabled, update the reminder time
    if (settings.notificationsEnabled) {
      toggleNotifications(true);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <CustomHeader title="Settings" />
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>Preferences</Text>
          
          <View style={[styles.settingItem, { 
            backgroundColor: theme.white,
            borderColor: theme.border,
            shadowColor: theme.border,
          }]}>
            <View style={[styles.settingIconContainer, { 
              backgroundColor: theme.lightGray,
              borderColor: theme.border,
            }]}>
              <Bell size={20} color={theme.text} />
            </View>
            <View style={styles.settingContent}>
              <Text style={[styles.settingTitle, { color: theme.text }]}>Daily Reminders</Text>
              <Text style={[styles.settingDescription, { color: theme.darkGray }]}>Receive notifications to meditate</Text>
            </View>
            <Switch
              value={settings.notificationsEnabled}
              onValueChange={(value) => toggleNotifications(value)}
              trackColor={{ false: theme.lightGray, true: theme.primary }}
              thumbColor={theme.white}
              ios_backgroundColor={theme.lightGray}
            />
          </View>
          
          {settings.notificationsEnabled && (
            <Pressable
              style={({ pressed }) => [
                styles.settingItem, 
                { 
                  backgroundColor: theme.white,
                  borderColor: theme.border,
                  shadowColor: theme.border,
                },
                pressed && styles.buttonPressed
              ]}
              onPress={() => setTimePickerVisible(true)}
            >
              <View style={[styles.settingIconContainer, { 
                backgroundColor: theme.lightGray,
                borderColor: theme.border,
              }]}>
                <Clock size={20} color={theme.text} />
              </View>
              <View style={styles.settingContent}>
                <Text style={[styles.settingTitle, { color: theme.text }]}>Reminder Time</Text>
                <Text style={[styles.settingDescription, { color: theme.darkGray }]}>
                  {formatTime(reminderTime.hour, reminderTime.minute)}
                </Text>
              </View>
              <ChevronRight size={20} color={theme.darkGray} />
            </Pressable>
          )}
          
          <View style={[styles.settingItem, { 
            backgroundColor: theme.white,
            borderColor: theme.border,
            shadowColor: theme.border,
          }]}>
            <View style={[styles.settingIconContainer, { 
              backgroundColor: theme.lightGray,
              borderColor: theme.border,
            }]}>
              <Moon size={20} color={theme.text} />
            </View>
            <View style={styles.settingContent}>
              <Text style={[styles.settingTitle, { color: theme.text }]}>Dark Mode</Text>
              <Text style={[styles.settingDescription, { color: theme.darkGray }]}>Switch to dark theme</Text>
            </View>
            <Switch
              value={isDark}
              onValueChange={(value) => toggleDarkMode(value)}
              trackColor={{ false: theme.lightGray, true: theme.primary }}
              thumbColor={theme.white}
              ios_backgroundColor={theme.lightGray}
            />
          </View>
          
          <View style={[styles.settingItem, { 
            backgroundColor: theme.white,
            borderColor: theme.border,
            shadowColor: theme.border,
          }]}>
            <View style={[styles.settingIconContainer, { 
              backgroundColor: theme.lightGray,
              borderColor: theme.border,
            }]}>
              <Volume2 size={20} color={theme.text} />
            </View>
            <View style={styles.settingContent}>
              <Text style={[styles.settingTitle, { color: theme.text }]}>Sound Effects</Text>
              <Text style={[styles.settingDescription, { color: theme.darkGray }]}>Play sounds for actions</Text>
            </View>
            <Switch
              value={settings.soundEffectsEnabled}
              onValueChange={(value) => updateSettings({ soundEffectsEnabled: value })}
              trackColor={{ false: theme.lightGray, true: theme.primary }}
              thumbColor={theme.white}
              ios_backgroundColor={theme.lightGray}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>Data</Text>
          
          <Pressable
            style={({ pressed }) => [
              styles.dataButton,
              { borderColor: theme.error, shadowColor: theme.border, backgroundColor: theme.white },
              pressed && styles.buttonPressed
            ]}
            onPress={handleClearData}
          >
            <Trash2 size={20} color={theme.error} />
            <Text style={[styles.dataButtonText, { color: theme.error }]}>Clear All Data</Text>
          </Pressable>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>About</Text>
          
          <Pressable 
            style={({ pressed }) => [
              styles.aboutItem,
              { 
                backgroundColor: theme.white,
                borderColor: theme.border,
                shadowColor: theme.border,
              },
              pressed && styles.buttonPressed
            ]}
            onPress={() => navigateToAbout('about')}
          >
            <View style={styles.aboutContent}>
              <Text style={[styles.aboutTitle, { color: theme.text }]}>About Meditate</Text>
            </View>
            <ChevronRight size={20} color={theme.darkGray} />
          </Pressable>
          
          <Pressable 
            style={({ pressed }) => [
              styles.aboutItem,
              { 
                backgroundColor: theme.white,
                borderColor: theme.border,
                shadowColor: theme.border,
              },
              pressed && styles.buttonPressed
            ]}
            onPress={() => navigateToAbout('privacy')}
          >
            <View style={styles.aboutContent}>
              <Text style={[styles.aboutTitle, { color: theme.text }]}>Privacy Policy</Text>
            </View>
            <ChevronRight size={20} color={theme.darkGray} />
          </Pressable>
          
          <Pressable 
            style={({ pressed }) => [
              styles.aboutItem,
              { 
                backgroundColor: theme.white,
                borderColor: theme.border,
                shadowColor: theme.border,
              },
              pressed && styles.buttonPressed
            ]}
            onPress={() => navigateToAbout('terms')}
          >
            <View style={styles.aboutContent}>
              <Text style={[styles.aboutTitle, { color: theme.text }]}>Terms of Service</Text>
            </View>
            <ChevronRight size={20} color={theme.darkGray} />
          </Pressable>
        </View>

        <View style={styles.versionContainer}>
          <Text style={[styles.versionText, { color: theme.darkGray }]}>Version 1.0.0</Text>
        </View>
      </ScrollView>
      
      <Modal
        visible={timePickerVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setTimePickerVisible(false)}
      >
        <TimePicker
          initialHour={reminderTime.hour}
          initialMinute={reminderTime.minute}
          onCancel={() => setTimePickerVisible(false)}
          onConfirm={handleTimeSelected}
        />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 2,
    padding: 16,
    marginBottom: 12,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  settingIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 2,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  settingDescription: {
    fontSize: 14,
    marginTop: 2,
  },
  dataButton: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 2,
    padding: 16,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  buttonPressed: {
    transform: [{ translateY: 3 }, { translateX: 3 }],
    shadowOffset: { width: 0, height: 0 },
  },
  dataButtonText: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 12,
  },
  aboutItem: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 2,
    padding: 16,
    marginBottom: 12,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  aboutContent: {
    flex: 1,
  },
  aboutTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  versionContainer: {
    alignItems: 'center',
    marginTop: 32,
  },
  versionText: {
    fontSize: 14,
  },
});