import React from 'react';
import { StyleSheet, Text, View, ScrollView, SafeAreaView } from 'react-native';
import { MEDITATIONS } from '@/constants/meditations';
import MeditationCard from '@/components/MeditationCard';
import StatsCard from '@/components/StatsCard';
import CustomHeader from '@/components/CustomHeader';
import useStore from '@/store/meditation-store';
import { useTheme } from '@/contexts/ThemeContext';

export default function HomeScreen() {
  const { setCurrentMeditation, setSelectedDuration, stats } = useStore();
  const { theme } = useTheme();

  const handleMeditationSelect = (id: string) => {
    // Find the meditation to get its default duration
    const meditation = MEDITATIONS.find(m => m.id === id);
    if (meditation) {
      setCurrentMeditation(id);
      setSelectedDuration(meditation.duration);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <CustomHeader title="Meditate" />
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={[styles.welcomeText, { color: theme.darkGray }]}>Welcome to</Text>
          <Text style={[styles.title, { color: theme.text }]}>Meditate</Text>
          <Text style={[styles.subtitle, { color: theme.darkGray }]}>Find your inner peace</Text>
        </View>

        {stats.totalSessions > 0 && <StatsCard stats={stats} />}

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>Meditations</Text>
        </View>

        {MEDITATIONS.map((meditation) => (
          <MeditationCard
            key={meditation.id}
            meditation={meditation}
            onPress={() => handleMeditationSelect(meditation.id)}
          />
        ))}

        <View style={styles.emptySpace} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  header: {
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  welcomeText: {
    fontSize: 16,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 8,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  emptySpace: {
    height: 40,
  },
});