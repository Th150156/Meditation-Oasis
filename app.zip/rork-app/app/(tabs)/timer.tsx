import React, { useEffect } from 'react';
import { StyleSheet, Text, View, ScrollView, SafeAreaView, Platform, StatusBar } from 'react-native';
import { AMBIENT_SOUNDS } from '@/constants/sounds';
import CircleTimer from '@/components/CircleTimer';
import DurationPicker from '@/components/DurationPicker';
import SoundButton from '@/components/SoundButton';
import AudioPlayer from '@/components/AudioPlayer';
import CustomHeader from '@/components/CustomHeader';
import useStore from '@/store/meditation-store';
import useAudioStore from '@/store/audio-store';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';

export default function TimerScreen() {
  const {
    currentMeditationId,
    selectedDuration,
    isTimerRunning,
    remainingTime,
    selectedSoundId,
    startTimer,
    pauseTimer,
    resetTimer,
    decrementTimer,
    setSelectedDuration,
    setSelectedSound,
  } = useStore();

  const {
    isPlaying,
    volume,
    togglePlay,
    setVolume,
  } = useAudioStore();
  
  const { theme } = useTheme();

  // Get the current meditation
  const currentMeditation = require('@/constants/meditations').MEDITATIONS.find(
    (m: any) => m.id === currentMeditationId
  ) || require('@/constants/meditations').MEDITATIONS[0];

  // Get the current sound
  const currentSound = AMBIENT_SOUNDS.find(s => s.id === selectedSoundId) || AMBIENT_SOUNDS[0];

  // Available durations in minutes
  const availableDurations = [1, 3, 5, 10, 15, 20, 30];

  // Timer interval
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isTimerRunning) {
      interval = setInterval(() => {
        decrementTimer();
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, decrementTimer]);

  // Handle timer controls with haptic feedback
  const handleStart = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    startTimer();
  };

  const handlePause = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    pauseTimer();
  };

  const handleReset = () => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }
    resetTimer();
  };

  // Calculate status bar height for proper spacing
  const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 44 : StatusBar.currentHeight || 0;

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      {/* Don't wrap the entire screen in SafeAreaView, as we handle safe areas separately */}
      <CustomHeader 
        title={currentMeditation.title} 
        showBackButton={true}
      />
      
      <ScrollView 
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: 16 } // Add padding at the top
        ]}
      >
        <View style={styles.header}>
          <Text style={[styles.description, { color: theme.darkGray }]}>{currentMeditation.description}</Text>
        </View>

        <CircleTimer
          duration={selectedDuration}
          remainingTime={remainingTime}
          isRunning={isTimerRunning}
          onStart={handleStart}
          onPause={handlePause}
          onReset={handleReset}
        />

        {!isTimerRunning && (
          <View style={styles.settingsContainer}>
            <DurationPicker
              durations={availableDurations}
              selectedDuration={selectedDuration / 60} // Convert seconds to minutes
              onSelectDuration={(duration) => setSelectedDuration(duration)}
            />

            <View style={styles.soundsSection}>
              <Text style={[styles.soundsLabel, { color: theme.text }]}>Ambient Sound</Text>
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.soundsScrollContent}
              >
                {AMBIENT_SOUNDS.map((sound) => (
                  <SoundButton
                    key={sound.id}
                    sound={sound}
                    isSelected={selectedSoundId === sound.id}
                    onPress={() => setSelectedSound(sound.id)}
                  />
                ))}
              </ScrollView>
            </View>
            
            {selectedSoundId !== 'none' && (
              <View style={styles.audioPlayerContainer}>
                <AudioPlayer
                  sound={currentSound}
                  isPlaying={isPlaying}
                  onTogglePlay={togglePlay}
                  volume={volume}
                  onVolumeChange={setVolume}
                />
              </View>
            )}
          </View>
        )}
        
        {/* Add extra padding at the bottom to avoid tab bar overlap */}
        <View style={{ height: Platform.OS === 'ios' ? 100 : 80 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 24,
  },
  header: {
    padding: 16,
    alignItems: 'center',
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    marginHorizontal: 24,
  },
  settingsContainer: {
    padding: 16,
  },
  soundsSection: {
    marginTop: 16,
  },
  soundsLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    marginLeft: 4,
  },
  soundsScrollContent: {
    paddingRight: 16,
  },
  audioPlayerContainer: {
    marginTop: 16,
  },
});