import React, { useState } from 'react';
import { StyleSheet, Text, View, ScrollView, SafeAreaView, Pressable } from 'react-native';
import useStore from '@/store/meditation-store';
import StatsCard from '@/components/StatsCard';
import SessionHistoryItem from '@/components/SessionHistoryItem';
import StreakCalendar from '@/components/StreakCalendar';
import StatisticsChart from '@/components/StatisticsChart';
import CustomHeader from '@/components/CustomHeader';
import { Calendar, ChevronDown, ChevronUp } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

export default function StatsScreen() {
  const { sessions, stats } = useStore();
  const { theme } = useTheme();
  
  const [timeRange, setTimeRange] = useState<7 | 30 | 90>(7);
  const [showAllSessions, setShowAllSessions] = useState(false);

  // Sort sessions by date (newest first)
  const sortedSessions = [...sessions].sort((a, b) => {
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });
  
  // Limit the number of sessions shown
  const displayedSessions = showAllSessions 
    ? sortedSessions 
    : sortedSessions.slice(0, 5);
  
  const toggleShowAllSessions = () => {
    setShowAllSessions(!showAllSessions);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <CustomHeader title="Your Progress" />
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <StatsCard stats={stats} />
        
        {stats.totalSessions > 0 && (
          <>
            <StreakCalendar 
              sessions={sessions} 
              currentStreak={stats.currentStreak} 
            />
            
            <View style={[styles.chartContainer, { 
              backgroundColor: theme.white,
              borderColor: theme.border,
              shadowColor: theme.border,
            }]}>
              <View style={styles.chartHeader}>
                <Text style={[styles.chartTitle, { color: theme.text }]}>Minutes Meditated</Text>
                <View style={styles.timeRangeButtons}>
                  <Pressable
                    style={[
                      styles.timeRangeButton,
                      timeRange === 7 && [styles.activeTimeRange, { backgroundColor: theme.primary }]
                    ]}
                    onPress={() => setTimeRange(7)}
                  >
                    <Text style={[
                      styles.timeRangeText,
                      timeRange === 7 && { color: theme.white }
                    ]}>Week</Text>
                  </Pressable>
                  <Pressable
                    style={[
                      styles.timeRangeButton,
                      timeRange === 30 && [styles.activeTimeRange, { backgroundColor: theme.primary }]
                    ]}
                    onPress={() => setTimeRange(30)}
                  >
                    <Text style={[
                      styles.timeRangeText,
                      timeRange === 30 && { color: theme.white }
                    ]}>Month</Text>
                  </Pressable>
                  <Pressable
                    style={[
                      styles.timeRangeButton,
                      timeRange === 90 && [styles.activeTimeRange, { backgroundColor: theme.primary }]
                    ]}
                    onPress={() => setTimeRange(90)}
                  >
                    <Text style={[
                      styles.timeRangeText,
                      timeRange === 90 && { color: theme.white }
                    ]}>3 Months</Text>
                  </Pressable>
                </View>
              </View>
              
              <StatisticsChart 
                sessions={sessions} 
                days={timeRange} 
              />
            </View>
          </>
        )}

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>Session History</Text>
        </View>

        {sortedSessions.length > 0 ? (
          <>
            {displayedSessions.map((session) => (
              <SessionHistoryItem key={session.id} session={session} />
            ))}
            
            {sortedSessions.length > 5 && (
              <Pressable
                style={[styles.showMoreButton, { 
                  backgroundColor: theme.white,
                  borderColor: theme.border,
                  shadowColor: theme.border,
                }]}
                onPress={toggleShowAllSessions}
              >
                <Text style={[styles.showMoreText, { color: theme.text }]}>
                  {showAllSessions ? 'Show Less' : `Show All (${sortedSessions.length})`}
                </Text>
                {showAllSessions ? (
                  <ChevronUp size={16} color={theme.text} />
                ) : (
                  <ChevronDown size={16} color={theme.text} />
                )}
              </Pressable>
            )}
          </>
        ) : (
          <View style={styles.emptyState}>
            <Calendar size={48} color={theme.darkGray} />
            <Text style={[styles.emptyStateText, { color: theme.darkGray }]}>No meditation sessions yet</Text>
            <Text style={[styles.emptyStateSubtext, { color: theme.darkGray }]}>
              Complete your first meditation to see your history here
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  chartContainer: {
    borderRadius: 12,
    borderWidth: 3,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  timeRangeButtons: {
    flexDirection: 'row',
  },
  timeRangeButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginLeft: 4,
    borderRadius: 4,
  },
  activeTimeRange: {
    borderRadius: 4,
  },
  timeRangeText: {
    fontSize: 12,
    fontWeight: '500',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 24,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  showMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 8,
    borderWidth: 2,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  showMoreText: {
    fontSize: 14,
    fontWeight: '500',
    marginRight: 4,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    marginTop: 16,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
  },
  emptyStateSubtext: {
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
  },
});