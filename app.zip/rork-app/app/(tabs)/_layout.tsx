import React from 'react';
import { Tabs } from 'expo-router';
import { Home, Timer, BarChart2, Settings } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { View, StyleSheet, Platform } from 'react-native';

export default function TabLayout() {
  const { theme } = useTheme();
  
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: theme.primary,
        tabBarInactiveTintColor: theme.darkGray,
        tabBarStyle: {
          borderTopWidth: 3,
          borderTopColor: theme.border,
          backgroundColor: theme.white,
          height: Platform.OS === 'ios' ? 88 : 60, // Increased height for iOS to account for safe area
          paddingTop: 8,
          paddingBottom: Platform.OS === 'ios' ? 28 : 8, // Extra padding at bottom for iOS
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
        },
        headerShown: false, // Hide the default header
        tabBarBackground: () => (
          <View style={[styles.tabBarBackground, { backgroundColor: theme.white }]} />
        ),
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Meditate',
          tabBarLabel: 'Home',
          tabBarIcon: ({ color }) => <Home size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="timer"
        options={{
          title: 'Timer',
          tabBarIcon: ({ color }) => <Timer size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="stats"
        options={{
          title: 'Stats',
          tabBarIcon: ({ color }) => <BarChart2 size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarIcon: ({ color }) => <Settings size={24} color={color} />,
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBarBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
});