export interface Meditation {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  color: string;
  icon: string;
}

export interface Sound {
  id: string;
  title: string;
  icon: string;
  url: string | null;
}

export interface MeditationSession {
  id: string;
  meditationId: string;
  date: string;
  duration: number; // in seconds
  completed: boolean;
}

export interface UserStats {
  totalSessions: number;
  totalMinutes: number;
  currentStreak: number;
  longestStreak: number;
  lastSessionDate: string | null;
}

export interface AppSettings {
  notificationsEnabled: boolean;
  darkMode: boolean;
  soundEffectsEnabled: boolean;
  completionSoundId: string;
}

export interface Theme {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  white: string;
  text: string;
  darkGray: string;
  lightGray: string;
  border: string;
  error: string;
  success: string;
}