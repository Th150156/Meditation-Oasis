import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MeditationSession } from '@/types/meditation';
import { MEDITATIONS } from '@/constants/meditations';
import { CheckCircle } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface SessionHistoryItemProps {
  session: MeditationSession;
}

const SessionHistoryItem: React.FC<SessionHistoryItemProps> = ({ session }) => {
  const { theme } = useTheme();
  
  // Find the meditation details
  const meditation = MEDITATIONS.find(m => m.id === session.meditationId);
  
  // Format the date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Format the time
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!meditation) return null;

  return (
    <View style={[styles.container, { 
      backgroundColor: theme.white,
      borderColor: theme.border,
      shadowColor: theme.border,
    }]}>
      <View style={[styles.colorIndicator, { backgroundColor: meditation.color }]} />
      
      <View style={styles.contentContainer}>
        <View style={styles.headerRow}>
          <Text style={[styles.title, { color: theme.text }]}>{meditation.title}</Text>
          {session.completed && (
            <CheckCircle size={18} color={theme.success} />
          )}
        </View>
        
        <View style={styles.detailsRow}>
          <Text style={[styles.date, { color: theme.darkGray }]}>{formatDate(session.date)}</Text>
          <Text style={[styles.time, { color: theme.darkGray }]}>{formatTime(session.date)}</Text>
          <Text style={[styles.duration, { 
            color: theme.darkGray,
            backgroundColor: theme.lightGray,
          }]}>{Math.round(session.duration / 60)} min</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderRadius: 10,
    borderWidth: 2,
    marginVertical: 6,
    marginHorizontal: 16,
    overflow: 'hidden',
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  colorIndicator: {
    width: 8,
    height: '100%',
  },
  contentContainer: {
    flex: 1,
    padding: 12,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  detailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  date: {
    fontSize: 12,
    marginRight: 8,
  },
  time: {
    fontSize: 12,
    marginRight: 8,
  },
  duration: {
    fontSize: 12,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
});

export default SessionHistoryItem;