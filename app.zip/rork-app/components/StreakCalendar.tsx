import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { MeditationSession } from '@/types/meditation';
import { useTheme } from '@/contexts/ThemeContext';

interface StreakCalendarProps {
  sessions: MeditationSession[];
  currentStreak: number;
}

const StreakCalendar: React.FC<StreakCalendarProps> = ({ sessions, currentStreak }) => {
  const { theme } = useTheme();
  
  // Get dates for the last 30 days
  const getDates = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(today.getDate() - i);
      dates.push(date);
    }
    
    return dates;
  };
  
  const last30Days = getDates();
  
  // Check if there was a session on a specific date
  const hasSessionOnDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return sessions.some(session => {
      const sessionDate = new Date(session.date).toISOString().split('T')[0];
      return sessionDate === dateString;
    });
  };
  
  // Format day name (e.g., "Mon")
  const formatDayName = (date: Date) => {
    return date.toLocaleDateString('en-US', { weekday: 'short' }).substring(0, 1);
  };
  
  // Format day number (e.g., "15")
  const formatDayNumber = (date: Date) => {
    return date.getDate().toString();
  };
  
  // Check if date is today
  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
  };

  return (
    <View style={[styles.container, { 
      backgroundColor: theme.white,
      borderColor: theme.border,
      shadowColor: theme.border,
    }]}>
      <View style={styles.headerRow}>
        <Text style={[styles.title, { color: theme.text }]}>Meditation Streak</Text>
        <View style={[styles.streakBadge, { 
          backgroundColor: theme.primary,
          borderColor: theme.border,
        }]}>
          <Text style={styles.streakText}>{currentStreak} days</Text>
        </View>
      </View>
      
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.calendarContainer}
      >
        {last30Days.map((date, index) => (
          <View 
            key={index} 
            style={[
              styles.dateItem,
              isToday(date) && [styles.today, { backgroundColor: theme.lightGray }]
            ]}
          >
            <Text style={[styles.dayName, { color: theme.darkGray }]}>{formatDayName(date)}</Text>
            <View style={[
              styles.dateCircle,
              { 
                backgroundColor: hasSessionOnDate(date) ? theme.secondary : theme.lightGray,
                borderColor: theme.border,
              },
              isToday(date) && { borderColor: theme.primary }
            ]}>
              <Text style={[
                styles.dateNumber,
                { color: hasSessionOnDate(date) ? theme.white : theme.text },
                isToday(date) && { fontWeight: 'bold' }
              ]}>
                {formatDayNumber(date)}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    borderWidth: 3,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  streakBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 2,
  },
  streakText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  calendarContainer: {
    paddingRight: 16,
  },
  dateItem: {
    alignItems: 'center',
    marginRight: 8,
    width: 40,
  },
  today: {
    borderRadius: 8,
    padding: 4,
    marginTop: -4,
    marginBottom: -4,
  },
  dayName: {
    fontSize: 12,
    marginBottom: 4,
  },
  dateCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
  },
  dateNumber: {
    fontSize: 14,
    fontWeight: '500',
  },
});

export default StreakCalendar;