import React from 'react';
import { StyleSheet, Text, View, ScrollView, Image } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface AboutSectionProps {
  type: 'about' | 'privacy' | 'terms';
}

const AboutSection: React.FC<AboutSectionProps> = ({ type }) => {
  const { theme } = useTheme();
  
  const getContent = () => {
    switch (type) {
      case 'about':
        return {
          title: 'About Meditate',
          content: [
            'Meditate is a mindfulness app designed to help you find peace and calm in your daily life.',
            'Our mission is to make meditation accessible to everyone, regardless of experience level.',
            'Regular meditation has been shown to reduce stress, improve focus, and promote overall well-being.',
            'We offer a variety of guided meditations to help you develop a consistent practice.',
            'The app was created with love by a team passionate about mental health and wellness.',
          ],
          imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=500&auto=format&fit=crop',
        };
      case 'privacy':
        return {
          title: 'Privacy Policy',
          content: [
            'Last updated: June 2023',
            'Your privacy is important to us. This Privacy Policy explains how we collect, use, and safeguard your information when you use our Meditate app.',
            'Information We Collect:',
            '• Usage data: We collect anonymous data about how you use the app to improve our service.',
            '• Meditation sessions: We store your meditation history to provide you with statistics and track your progress.',
            '• All data is stored locally on your device and is not shared with third parties.',
            'We use industry-standard security measures to protect your data, but no method of transmission over the internet is 100% secure.',
            'If you have any questions about our Privacy Policy, please contact us at privacy@meditate-app.com.',
          ],
        };
      case 'terms':
        return {
          title: 'Terms of Service',
          content: [
            'Last updated: June 2023',
            'By using the Meditate app, you agree to these Terms of Service.',
            'License: We grant you a limited, non-exclusive, non-transferable license to use the app for personal, non-commercial purposes.',
            'Restrictions: You may not:',
            '• Modify, reverse engineer, or create derivative works based on the app',
            '• Remove any proprietary notices from the app',
            '• Use the app for any illegal purpose',
            'Disclaimer: The app is provided "as is" without warranties of any kind.',
            'Limitation of Liability: We shall not be liable for any indirect, incidental, special, or consequential damages.',
            'These terms may be updated from time to time. Continued use of the app constitutes acceptance of any changes.',
          ],
        };
      default:
        return {
          title: '',
          content: [],
        };
    }
  };

  const { title, content, imageUrl } = getContent();

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.background }]} contentContainerStyle={styles.contentContainer}>
      <Text style={[styles.title, { color: theme.text }]}>{title}</Text>
      
      {imageUrl && (
        <View style={[styles.imageContainer, { 
          borderColor: theme.border,
          shadowColor: theme.border,
        }]}>
          <Image 
            source={{ uri: imageUrl }} 
            style={styles.image}
            resizeMode="cover"
          />
        </View>
      )}
      
      <View style={[styles.textContainer, { 
        backgroundColor: theme.white,
        borderColor: theme.border,
        shadowColor: theme.border,
      }]}>
        {content.map((paragraph, index) => (
          <Text key={index} style={[styles.paragraph, { color: theme.text }]}>
            {paragraph}
          </Text>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  imageContainer: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 3,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  textContainer: {
    borderRadius: 12,
    borderWidth: 3,
    padding: 16,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  paragraph: {
    fontSize: 16,
    marginBottom: 12,
    lineHeight: 24,
  },
});

export default AboutSection;