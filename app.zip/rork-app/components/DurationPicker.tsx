import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface DurationPickerProps {
  durations: number[]; // in minutes
  selectedDuration: number; // in minutes
  onSelectDuration: (duration: number) => void;
}

const DurationPicker: React.FC<DurationPickerProps> = ({
  durations,
  selectedDuration,
  onSelectDuration,
}) => {
  const { theme } = useTheme();
  
  return (
    <View style={styles.container}>
      <Text style={[styles.label, { color: theme.text }]}>Duration</Text>
      <View style={styles.buttonsContainer}>
        {durations.map((duration) => (
          <Pressable
            key={duration}
            style={({ pressed }) => [
              styles.durationButton,
              { 
                backgroundColor: duration === selectedDuration ? theme.primary : theme.white,
                borderColor: theme.border,
                shadowColor: theme.border,
              },
              pressed && styles.buttonPressed,
            ]}
            onPress={() => onSelectDuration(duration)}
          >
            <Text
              style={[
                styles.durationText,
                { color: duration === selectedDuration ? theme.white : theme.text },
              ]}
            >
              {duration} min
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    marginLeft: 4,
  },
  buttonsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  durationButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 2,
    marginRight: 8,
    marginBottom: 8,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 3,
  },
  buttonPressed: {
    transform: [{ translateY: 2 }, { translateX: 2 }],
    shadowOffset: { width: 0, height: 0 },
  },
  durationText: {
    fontSize: 14,
    fontWeight: '500',
  },
});

export default DurationPicker;