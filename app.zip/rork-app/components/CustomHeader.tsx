import React from 'react';
import { StyleSheet, Text, View, Pressable, Platform, StatusBar } from 'react-native';
import { useRouter, useNavigation } from 'expo-router';
import { ChevronLeft } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';

interface CustomHeaderProps {
  title: string;
  showBackButton?: boolean;
  rightElement?: React.ReactNode;
}

const CustomHeader: React.FC<CustomHeaderProps> = ({ 
  title, 
  showBackButton = false,
  rightElement
}) => {
  const router = useRouter();
  const navigation = useNavigation();
  const { theme } = useTheme();

  const handleBack = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.back();
  };

  // Calculate status bar height for proper spacing
  const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 44 : StatusBar.currentHeight || 0;

  return (
    <View style={[styles.container, { 
      backgroundColor: theme.white,
      borderBottomColor: theme.border,
      shadowColor: theme.border,
      paddingTop: STATUSBAR_HEIGHT, // Add padding for status bar
      height: 60 + STATUSBAR_HEIGHT, // Adjust height to include status bar
    }]}>
      <View style={styles.leftContainer}>
        {showBackButton && navigation.canGoBack() && (
          <Pressable 
            style={({ pressed }) => [
              styles.backButton,
              { 
                backgroundColor: theme.white,
                borderColor: theme.border,
                shadowColor: theme.border,
              },
              pressed && styles.buttonPressed
            ]}
            onPress={handleBack}
          >
            <ChevronLeft size={24} color={theme.text} />
          </Pressable>
        )}
      </View>
      
      <Text style={[styles.title, { color: theme.text }]}>{title}</Text>
      
      <View style={styles.rightContainer}>
        {rightElement}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 3,
    paddingHorizontal: 16,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 8,
    zIndex: 100,
  },
  leftContainer: {
    position: 'absolute',
    left: 16,
    zIndex: 10,
    bottom: 10, // Position from bottom for consistent placement
  },
  rightContainer: {
    position: 'absolute',
    right: 16,
    zIndex: 10,
    bottom: 10, // Position from bottom for consistent placement
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    position: 'absolute',
    bottom: 16, // Position from bottom for consistent placement
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  buttonPressed: {
    transform: [{ translateY: 2 }, { translateX: 2 }],
    shadowOffset: { width: 0, height: 0 },
  },
});

export default CustomHeader;