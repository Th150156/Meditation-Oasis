import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MeditationSession } from '@/types/meditation';
import { useTheme } from '@/contexts/ThemeContext';

interface StatisticsChartProps {
  sessions: MeditationSession[];
  days: number;
}

const StatisticsChart: React.FC<StatisticsChartProps> = ({ sessions, days = 7 }) => {
  const { theme } = useTheme();
  
  // Get dates for the specified number of days
  const getDates = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(today.getDate() - i);
      dates.push(date);
    }
    
    return dates;
  };
  
  const recentDates = getDates();
  
  // Calculate minutes meditated for each day
  const getMinutesForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    const sessionsOnDate = sessions.filter(session => {
      const sessionDate = new Date(session.date).toISOString().split('T')[0];
      return sessionDate === dateString;
    });
    
    return Math.round(sessionsOnDate.reduce((total, session) => total + session.duration, 0) / 60);
  };
  
  // Format day (e.g., "Mon")
  const formatDay = (date: Date) => {
    if (days <= 7) {
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    } else if (days <= 31) {
      return `${date.getDate()}/${date.getMonth() + 1}`;
    } else {
      return `${date.getDate()}/${date.getMonth() + 1}`;
    }
  };
  
  // Find the maximum minutes for scaling
  const minutesData = recentDates.map(date => getMinutesForDate(date));
  const maxMinutes = Math.max(...minutesData, 10); // Minimum of 10 for scaling
  
  // Calculate bar height percentage
  const getBarHeight = (minutes: number) => {
    return (minutes / maxMinutes) * 100;
  };
  
  // For larger date ranges, we need to show fewer bars
  const displayDates = days <= 7 
    ? recentDates 
    : days <= 30 
      ? recentDates.filter((_, i) => i % 3 === 0 || i === recentDates.length - 1)
      : recentDates.filter((_, i) => i % 7 === 0 || i === recentDates.length - 1);

  return (
    <View style={styles.chartContainer}>
      {displayDates.map((date, index) => {
        const minutes = getMinutesForDate(date);
        const heightPercentage = getBarHeight(minutes);
        
        return (
          <View key={index} style={styles.barContainer}>
            <Text style={[styles.minutesText, { color: theme.darkGray }]}>
              {minutes > 0 ? minutes : ''}
            </Text>
            <View style={[styles.barBackground, { 
              backgroundColor: theme.lightGray,
              borderColor: theme.border,
            }]}>
              <View 
                style={[
                  styles.bar, 
                  { height: `${heightPercentage}%` },
                  minutes > 0 ? { backgroundColor: theme.primary } : { backgroundColor: 'transparent' }
                ]} 
              />
            </View>
            <Text style={[styles.dayText, { color: theme.darkGray }]}>{formatDay(date)}</Text>
          </View>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 180,
  },
  barContainer: {
    flex: 1,
    alignItems: 'center',
  },
  minutesText: {
    fontSize: 12,
    marginBottom: 4,
    height: 16,
  },
  barBackground: {
    width: 24,
    height: 120,
    borderRadius: 4,
    borderWidth: 2,
    justifyContent: 'flex-end',
    overflow: 'hidden',
  },
  bar: {
    width: '100%',
    borderTopLeftRadius: 2,
    borderTopRightRadius: 2,
  },
  dayText: {
    fontSize: 12,
    marginTop: 8,
  },
});

export default StatisticsChart;