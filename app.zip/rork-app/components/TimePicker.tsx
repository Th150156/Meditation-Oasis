import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Platform } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useTheme } from '@/contexts/ThemeContext';
import * as Haptics from 'expo-haptics';

interface TimePickerProps {
  initialHour: number;
  initialMinute: number;
  onCancel: () => void;
  onConfirm: (hour: number, minute: number) => void;
}

const TimePicker: React.FC<TimePickerProps> = ({
  initialHour,
  initialMinute,
  onCancel,
  onConfirm,
}) => {
  const [hour, setHour] = useState(initialHour.toString());
  const [minute, setMinute] = useState(initialMinute.toString());
  const { theme } = useTheme();

  const handleConfirm = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onConfirm(parseInt(hour, 10), parseInt(minute, 10));
  };

  const handleCancel = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onCancel();
  };

  // Generate hours (0-23)
  const hours = Array.from({ length: 24 }, (_, i) => {
    const period = i >= 12 ? 'PM' : 'AM';
    const displayHour = i % 12 === 0 ? 12 : i % 12;
    return {
      value: i.toString(),
      label: `${displayHour} ${period}`,
    };
  });

  // Generate minutes (0-59)
  const minutes = Array.from({ length: 60 }, (_, i) => ({
    value: i.toString(),
    label: i.toString().padStart(2, '0'),
  }));

  return (
    <View style={styles.modalContainer}>
      <View style={[styles.pickerContainer, { 
        backgroundColor: theme.white,
        borderColor: theme.border,
        shadowColor: theme.border,
      }]}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.text }]}>Set Reminder Time</Text>
        </View>

        <View style={styles.pickerRow}>
          {/* Hour Picker */}
          <View style={styles.pickerColumn}>
            <Text style={[styles.pickerLabel, { color: theme.darkGray }]}>Hour</Text>
            <Picker
              selectedValue={hour}
              onValueChange={(itemValue) => setHour(itemValue.toString())}
              style={[styles.picker, { color: theme.text }]}
              itemStyle={{ color: theme.text }}
            >
              {hours.map((item) => (
                <Picker.Item key={item.value} label={item.label} value={item.value} />
              ))}
            </Picker>
          </View>

          {/* Minute Picker */}
          <View style={styles.pickerColumn}>
            <Text style={[styles.pickerLabel, { color: theme.darkGray }]}>Minute</Text>
            <Picker
              selectedValue={minute}
              onValueChange={(itemValue) => setMinute(itemValue.toString())}
              style={[styles.picker, { color: theme.text }]}
              itemStyle={{ color: theme.text }}
            >
              {minutes.map((item) => (
                <Picker.Item key={item.value} label={item.label} value={item.value} />
              ))}
            </Picker>
          </View>
        </View>

        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={[styles.button, styles.cancelButton, { 
              borderColor: theme.border,
              backgroundColor: theme.lightGray,
              shadowColor: theme.border,
            }]}
            onPress={handleCancel}
          >
            <Text style={[styles.buttonText, { color: theme.text }]}>Cancel</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.button, styles.confirmButton, { 
              borderColor: theme.border,
              backgroundColor: theme.primary,
              shadowColor: theme.border,
            }]}
            onPress={handleConfirm}
          >
            <Text style={[styles.buttonText, { color: theme.white }]}>Confirm</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  pickerContainer: {
    width: '80%',
    borderRadius: 16,
    borderWidth: 3,
    overflow: 'hidden',
    shadowOffset: { width: 5, height: 5 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 8,
  },
  header: {
    padding: 16,
    borderBottomWidth: 2,
    borderBottomColor: '#E5E5E5',
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  pickerRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 16,
  },
  pickerColumn: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  pickerLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  picker: {
    width: '100%',
    height: 150,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 16,
    borderTopWidth: 2,
    borderTopColor: '#E5E5E5',
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    borderWidth: 2,
    minWidth: 100,
    alignItems: 'center',
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  cancelButton: {
    marginRight: 8,
  },
  confirmButton: {
    marginLeft: 8,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default TimePicker;