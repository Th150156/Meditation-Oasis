import React from 'react';
import { StyleSheet, View, Text, Pressable, Platform } from 'react-native';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react-native';
import { Sound } from '@/types/meditation';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';

interface AudioPlayerProps {
  sound: Sound;
  isPlaying: boolean;
  onTogglePlay: () => void;
  volume: number;
  onVolumeChange: (volume: number) => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({
  sound,
  isPlaying,
  onTogglePlay,
  volume,
  onVolumeChange
}) => {
  const { theme } = useTheme();
  
  const handleTogglePlay = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onTogglePlay();
  };

  const handleVolumeChange = (newVolume: number) => {
    onVolumeChange(newVolume);
  };

  return (
    <View style={[styles.container, { 
      backgroundColor: theme.white,
      borderColor: theme.border,
      shadowColor: theme.border,
    }]}>
      <View style={styles.soundInfo}>
        <Text style={[styles.soundName, { color: theme.text }]}>{sound.title}</Text>
        <Text style={[styles.soundStatus, { color: theme.darkGray }]}>{isPlaying ? 'Playing' : 'Paused'}</Text>
      </View>
      
      <View style={styles.controls}>
        <Pressable
          style={({ pressed }) => [
            styles.controlButton,
            { 
              backgroundColor: theme.lightGray,
              borderColor: theme.border,
              shadowColor: theme.border,
            },
            pressed && styles.buttonPressed
          ]}
          onPress={handleTogglePlay}
        >
          {isPlaying ? (
            <Pause size={20} color={theme.text} />
          ) : (
            <Play size={20} color={theme.text} />
          )}
        </Pressable>
        
        <View style={styles.volumeContainer}>
          <Pressable
            style={styles.volumeButton}
            onPress={() => handleVolumeChange(0)}
          >
            <VolumeX size={16} color={volume === 0 ? theme.primary : theme.darkGray} />
          </Pressable>
          
          <View style={styles.volumeSlider}>
            {[0.25, 0.5, 0.75, 1].map((level) => (
              <Pressable
                key={level}
                style={[
                  styles.volumeLevel,
                  { 
                    backgroundColor: volume >= level ? theme.primary : theme.lightGray,
                    borderColor: theme.border,
                  }
                ]}
                onPress={() => handleVolumeChange(level)}
              />
            ))}
          </View>
          
          <Pressable
            style={styles.volumeButton}
            onPress={() => handleVolumeChange(1)}
          >
            <Volume2 size={16} color={volume === 1 ? theme.primary : theme.darkGray} />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    borderWidth: 3,
    padding: 16,
    marginBottom: 12,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  soundInfo: {
    marginBottom: 12,
  },
  soundName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  soundStatus: {
    fontSize: 14,
    marginTop: 4,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  controlButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    borderWidth: 2,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 3,
  },
  buttonPressed: {
    transform: [{ translateY: 2 }, { translateX: 2 }],
    shadowOffset: { width: 0, height: 0 },
  },
  volumeContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  volumeButton: {
    padding: 4,
  },
  volumeSlider: {
    flex: 1,
    flexDirection: 'row',
    height: 20,
    marginHorizontal: 8,
    justifyContent: 'space-between',
  },
  volumeLevel: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 1,
  },
});

export default AudioPlayer;