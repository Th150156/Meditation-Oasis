import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { UserStats } from '@/types/meditation';
import { Clock, Calendar, Flame } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface StatsCardProps {
  stats: UserStats;
}

const StatsCard: React.FC<StatsCardProps> = ({ stats }) => {
  const { theme } = useTheme();
  
  return (
    <View style={[styles.container, { 
      backgroundColor: theme.white,
      borderColor: theme.border,
      shadowColor: theme.border,
    }]}>
      <Text style={[styles.title, { color: theme.text }]}>Your Progress</Text>
      
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <View style={[styles.iconContainer, { 
            backgroundColor: theme.lightGray,
            borderColor: theme.border,
          }]}>
            <Calendar size={24} color={theme.text} />
          </View>
          <Text style={[styles.statValue, { color: theme.text }]}>{stats.totalSessions}</Text>
          <Text style={[styles.statLabel, { color: theme.darkGray }]}>Sessions</Text>
        </View>
        
        <View style={styles.statItem}>
          <View style={[styles.iconContainer, { 
            backgroundColor: theme.lightGray,
            borderColor: theme.border,
          }]}>
            <Clock size={24} color={theme.text} />
          </View>
          <Text style={[styles.statValue, { color: theme.text }]}>{stats.totalMinutes}</Text>
          <Text style={[styles.statLabel, { color: theme.darkGray }]}>Minutes</Text>
        </View>
        
        <View style={styles.statItem}>
          <View style={[styles.iconContainer, { 
            backgroundColor: theme.lightGray,
            borderColor: theme.border,
          }]}>
            <Flame size={24} color={theme.text} />
          </View>
          <Text style={[styles.statValue, { color: theme.text }]}>{stats.currentStreak}</Text>
          <Text style={[styles.statLabel, { color: theme.darkGray }]}>Day Streak</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    borderWidth: 3,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    borderWidth: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },
});

export default StatsCard;