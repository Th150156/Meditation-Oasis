import React from 'react';
import { StyleSheet, Text, Pressable, View } from 'react-native';
import { Sound } from '@/types/meditation';
import * as Icons from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface SoundButtonProps {
  sound: Sound;
  isSelected: boolean;
  onPress: () => void;
}

const SoundButton: React.FC<SoundButtonProps> = ({ sound, isSelected, onPress }) => {
  const { theme } = useTheme();
  
  // Dynamically get the icon component
  const IconComponent = (Icons as any)[sound.icon.charAt(0).toUpperCase() + sound.icon.slice(1)];

  return (
    <Pressable
      style={({ pressed }) => [
        styles.container,
        { 
          backgroundColor: isSelected ? theme.primary : theme.white,
          borderColor: theme.border,
        },
        pressed && styles.pressed
      ]}
      onPress={onPress}
    >
      <View style={[
        styles.iconContainer, 
        { 
          backgroundColor: isSelected ? 'rgba(255, 255, 255, 0.2)' : theme.lightGray,
          borderColor: isSelected ? theme.white : theme.border,
        }
      ]}>
        {IconComponent && <IconComponent size={20} color={isSelected ? theme.white : theme.text} />}
      </View>
      <Text style={[
        styles.text, 
        { color: isSelected ? theme.white : theme.text }
      ]}>
        {sound.title}
      </Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    marginRight: 8,
    marginBottom: 8,
    borderRadius: 8,
    borderWidth: 2,
  },
  pressed: {
    opacity: 0.8,
    transform: [{ scale: 0.98 }],
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
    borderWidth: 1,
  },
  text: {
    fontSize: 14,
    fontWeight: '500',
  },
});

export default SoundButton;