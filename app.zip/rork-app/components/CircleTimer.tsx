import React, { useEffect, useRef } from 'react';
import { StyleSheet, Text, View, Pressable, Animated } from 'react-native';
import { Play, Pause, RotateCcw } from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface CircleTimerProps {
  duration: number; // in seconds
  remainingTime: number; // in seconds
  isRunning: boolean;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
}

const CircleTimer: React.FC<CircleTimerProps> = ({
  duration,
  remainingTime,
  isRunning,
  onStart,
  onPause,
  onReset,
}) => {
  const { theme } = useTheme();
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Calculate progress percentage
  const progress = (duration - remainingTime) / duration;
  
  // Animation for progress
  const progressAnimation = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    Animated.timing(progressAnimation, {
      toValue: progress,
      duration: 300,
      useNativeDriver: false,
    }).start();
  }, [progress]);

  // Interpolate for the circle progress
  const circleCircumference = 2 * Math.PI * 120; // 120 is the radius
  const strokeDashoffset = progressAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: [circleCircumference, 0],
  });

  return (
    <View style={styles.container}>
      <View style={styles.timerContainer}>
        <Animated.View style={[styles.progressBackground, { borderColor: theme.lightGray }]}>
          <Animated.View
            style={[
              styles.progressCircle,
              {
                borderColor: theme.primary,
                borderWidth: 12,
                opacity: progressAnimation,
              },
            ]}
          />
        </Animated.View>
        
        <View style={[styles.timeContainer, { 
          backgroundColor: theme.white,
          borderColor: theme.border,
          shadowColor: theme.border,
        }]}>
          <Text style={[styles.timeText, { color: theme.text }]}>{formatTime(remainingTime)}</Text>
        </View>
      </View>

      <View style={styles.controlsContainer}>
        <Pressable
          style={({ pressed }) => [
            styles.controlButton, 
            { 
              backgroundColor: theme.white,
              borderColor: theme.border,
              shadowColor: theme.border,
            },
            pressed && styles.buttonPressed
          ]}
          onPress={onReset}
        >
          <RotateCcw size={24} color={theme.text} />
        </Pressable>
        
        <Pressable
          style={({ pressed }) => [
            styles.mainControlButton,
            { 
              backgroundColor: theme.primary,
              borderColor: theme.border,
              shadowColor: theme.border,
            },
            pressed && styles.buttonPressed
          ]}
          onPress={isRunning ? onPause : onStart}
        >
          {isRunning ? (
            <Pause size={32} color={theme.white} />
          ) : (
            <Play size={32} color={theme.white} />
          )}
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  timerContainer: {
    width: 280,
    height: 280,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  progressBackground: {
    width: 260,
    height: 260,
    borderRadius: 130,
    borderWidth: 12,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
  },
  progressCircle: {
    width: '100%',
    height: '100%',
    borderRadius: 130,
    position: 'absolute',
  },
  timeContainer: {
    width: 200,
    height: 200,
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  timeText: {
    fontSize: 48,
    fontWeight: 'bold',
  },
  controlsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  controlButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 16,
    borderWidth: 3,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 4,
  },
  mainControlButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  buttonPressed: {
    transform: [{ translateY: 4 }, { translateX: 4 }],
    shadowOffset: { width: 0, height: 0 },
  },
});

export default CircleTimer;