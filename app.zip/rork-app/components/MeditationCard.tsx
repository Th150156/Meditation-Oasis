import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Meditation } from '@/types/meditation';
import * as Icons from 'lucide-react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface MeditationCardProps {
  meditation: Meditation;
  onPress: () => void;
}

const MeditationCard: React.FC<MeditationCardProps> = ({ meditation, onPress }) => {
  const router = useRouter();
  const { theme } = useTheme();
  
  // Dynamically get the icon component
  const IconName = meditation.icon.charAt(0).toUpperCase() + meditation.icon.slice(1);
  const IconComponent = (Icons as any)[IconName];

  const handlePress = () => {
    onPress();
    router.push('/timer');
  };

  return (
    <Pressable 
      style={({ pressed }) => [
        styles.container,
        { 
          backgroundColor: meditation.color,
          borderColor: theme.border,
          shadowColor: theme.border,
        },
        pressed && styles.pressed
      ]}
      onPress={handlePress}
    >
      <View style={[styles.iconContainer, { borderColor: theme.border }]}>
        {IconComponent && <IconComponent size={32} color={theme.white} />}
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.title}>{meditation.title}</Text>
        <Text style={styles.duration}>{meditation.duration} min</Text>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 12,
    borderWidth: 3,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 0,
    elevation: 6,
  },
  pressed: {
    transform: [{ translateY: 4 }, { translateX: 4 }],
    shadowOffset: { width: 0, height: 0 },
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    borderWidth: 2,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  duration: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.8,
  },
});

export default MeditationCard;