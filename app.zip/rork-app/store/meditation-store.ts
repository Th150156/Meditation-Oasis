import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MeditationSession, UserStats } from '@/types/meditation';
import useAudioStore from './audio-store';
import useSettingsStore from './settings-store';

interface MeditationState {
  // Current session
  currentMeditationId: string | null;
  selectedDuration: number;
  isTimerRunning: boolean;
  remainingTime: number;
  selectedSoundId: string;
  
  // User stats
  sessions: MeditationSession[];
  stats: UserStats;
  
  // Actions
  setCurrentMeditation: (id: string) => void;
  setSelectedDuration: (duration: number) => void;
  startTimer: () => void;
  pauseTimer: () => void;
  resetTimer: () => void;
  decrementTimer: () => void;
  setSelectedSound: (id: string) => void;
  completeSession: () => void;
  updateStats: () => void;
  clearAllData: () => void;
}

const useStore = create<MeditationState>()(
  persist(
    (set, get) => ({
      // Current session
      currentMeditationId: null,
      selectedDuration: 5 * 60, // 5 minutes in seconds
      isTimerRunning: false,
      remainingTime: 5 * 60,
      selectedSoundId: 'none',
      
      // User stats
      sessions: [],
      stats: {
        totalSessions: 0,
        totalMinutes: 0,
        currentStreak: 0,
        longestStreak: 0,
        lastSessionDate: null,
      },
      
      // Actions
      setCurrentMeditation: (id: string) => {
        set({ currentMeditationId: id });
      },
      
      setSelectedDuration: (duration: number) => {
        set({ 
          selectedDuration: duration * 60, // Convert minutes to seconds
          remainingTime: duration * 60,
        });
      },
      
      startTimer: () => {
        set({ isTimerRunning: true });
        
        // Start playing the ambient sound if one is selected
        const { selectedSoundId } = get();
        if (selectedSoundId !== 'none') {
          const audioStore = useAudioStore.getState();
          audioStore.setCurrentSound(selectedSoundId);
          audioStore.setPlaying(true);
        }
      },
      
      pauseTimer: () => {
        set({ isTimerRunning: false });
        
        // Pause the ambient sound
        const audioStore = useAudioStore.getState();
        audioStore.setPlaying(false);
      },
      
      resetTimer: () => {
        const { selectedDuration } = get();
        set({ 
          isTimerRunning: false,
          remainingTime: selectedDuration,
        });
        
        // Stop the ambient sound
        const audioStore = useAudioStore.getState();
        audioStore.setPlaying(false);
      },
      
      decrementTimer: () => {
        const { remainingTime, isTimerRunning } = get();
        if (isTimerRunning && remainingTime > 0) {
          set({ remainingTime: remainingTime - 1 });
        } else if (isTimerRunning && remainingTime === 0) {
          set({ isTimerRunning: false });
          
          // Play completion sound
          const settingsStore = useSettingsStore.getState();
          const completionSoundId = settingsStore.settings.completionSoundId;
          const audioStore = useAudioStore.getState();
          
          // Stop ambient sound
          audioStore.setPlaying(false);
          
          // Play completion sound
          if (completionSoundId !== 'none') {
            audioStore.playCompletionSound(completionSoundId);
          }
          
          get().completeSession();
        }
      },
      
      setSelectedSound: (id: string) => {
        set({ selectedSoundId: id });
        
        // Update the audio store
        const audioStore = useAudioStore.getState();
        audioStore.setCurrentSound(id);
        
        // If timer is running, start playing the sound
        const { isTimerRunning } = get();
        if (isTimerRunning && id !== 'none') {
          audioStore.setPlaying(true);
        }
      },
      
      completeSession: () => {
        const { currentMeditationId, selectedDuration, sessions } = get();
        
        if (!currentMeditationId) return;
        
        const newSession: MeditationSession = {
          id: Date.now().toString(),
          meditationId: currentMeditationId,
          date: new Date().toISOString(),
          duration: selectedDuration,
          completed: true,
        };
        
        set({ 
          sessions: [...sessions, newSession],
          isTimerRunning: false,
        });
        
        get().updateStats();
      },
      
      updateStats: () => {
        const { sessions, stats } = get();
        
        // Calculate total sessions and minutes
        const totalSessions = sessions.length;
        const totalMinutes = Math.round(
          sessions.reduce((total, session) => total + session.duration, 0) / 60
        );
        
        // Calculate streak
        let currentStreak = 0;
        let longestStreak = stats.longestStreak;
        
        if (sessions.length > 0) {
          // Sort sessions by date
          const sortedSessions = [...sessions].sort((a, b) => 
            new Date(a.date).getTime() - new Date(b.date).getTime()
          );
          
          // Get unique dates
          const uniqueDates = new Set(
            sortedSessions.map(session => 
              new Date(session.date).toISOString().split('T')[0]
            )
          );
          
          const uniqueDatesArray = Array.from(uniqueDates);
          
          // Calculate current streak
          const today = new Date().toISOString().split('T')[0];
          const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
          
          // Check if meditated today
          const meditatedToday = uniqueDatesArray.includes(today);
          
          // Start counting streak
          if (meditatedToday) {
            currentStreak = 1;
            
            // Count backwards from yesterday
            let checkDate = yesterday;
            let daysBack = 1;
            
            while (uniqueDatesArray.includes(checkDate)) {
              currentStreak++;
              daysBack++;
              checkDate = new Date(Date.now() - (86400000 * daysBack)).toISOString().split('T')[0];
            }
          } else {
            // Check if meditated yesterday
            if (uniqueDatesArray.includes(yesterday)) {
              currentStreak = 1;
              
              // Count backwards from day before yesterday
              let checkDate = new Date(Date.now() - (86400000 * 2)).toISOString().split('T')[0];
              let daysBack = 2;
              
              while (uniqueDatesArray.includes(checkDate)) {
                currentStreak++;
                daysBack++;
                checkDate = new Date(Date.now() - (86400000 * daysBack)).toISOString().split('T')[0];
              }
            }
          }
          
          // Update longest streak if needed
          if (currentStreak > longestStreak) {
            longestStreak = currentStreak;
          }
        }
        
        set({
          stats: {
            totalSessions,
            totalMinutes,
            currentStreak,
            longestStreak,
            lastSessionDate: sessions.length > 0 
              ? sessions[sessions.length - 1].date 
              : null,
          }
        });
      },
      
      clearAllData: () => {
        set({
          sessions: [],
          stats: {
            totalSessions: 0,
            totalMinutes: 0,
            currentStreak: 0,
            longestStreak: 0,
            lastSessionDate: null,
          },
          currentMeditationId: null,
          selectedDuration: 5 * 60,
          isTimerRunning: false,
          remainingTime: 5 * 60,
          selectedSoundId: 'none',
        });
        
        // Stop any playing sounds
        const audioStore = useAudioStore.getState();
        audioStore.setCurrentSound(null);
        audioStore.setPlaying(false);
      },
    }),
    {
      name: 'meditation-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

export default useStore;