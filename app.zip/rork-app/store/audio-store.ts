import { create } from 'zustand';
import { Platform } from 'react-native';
import { Audio } from 'expo-av';
import { AMBIENT_SOUNDS, COMPLETION_SOUNDS } from '@/constants/sounds';

interface AudioState {
  // Audio state
  isInitialized: boolean;
  currentSoundId: string | null;
  isPlaying: boolean;
  volume: number;
  sound: Audio.Sound | null;
  
  // Actions
  initializeAudio: () => Promise<boolean>;
  setCurrentSound: (id: string | null) => void;
  togglePlay: () => void;
  setPlaying: (isPlaying: boolean) => void;
  setVolume: (volume: number) => void;
  playCompletionSound: (soundId: string) => void;
}

const useAudioStore = create<AudioState>((set, get) => {
  return {
    // Audio state
    isInitialized: false,
    currentSoundId: null,
    isPlaying: false,
    volume: 0.7,
    sound: null,
    
    // Initialize audio system
    initializeAudio: async () => {
      try {
        // Set up audio mode
        await Audio.setAudioModeAsync({
          playsInSilentModeIOS: true,
          staysActiveInBackground: true,
          shouldDuckAndroid: true,
        });
        
        set({ isInitialized: true });
        return true;
      } catch (error) {
        console.error('Error initializing audio:', error);
        return false;
      }
    },
    
    // Set and play a sound
    setCurrentSound: async (id: string | null) => {
      const { sound: currentSound } = get();
      
      // Unload current sound if it exists
      if (currentSound) {
        try {
          await currentSound.unloadAsync();
        } catch (error) {
          console.error('Error unloading current sound:', error);
        }
      }
      
      // If setting to null, just update state
      if (id === null || id === 'none') {
        set({ 
          currentSoundId: null, 
          isPlaying: false,
          sound: null
        });
        return;
      }
      
      try {
        // Find the sound in our list
        const soundData = AMBIENT_SOUNDS.find(s => s.id === id);
        if (!soundData || !soundData.url) {
          console.warn(`Sound with ID ${id} not found or has no URL`);
          return;
        }
        
        console.log(`Loading sound: ${soundData.url}`);
        // Load and play the sound
        const { sound: newSound } = await Audio.Sound.createAsync(
          { uri: soundData.url },
          { 
            isLooping: true,
            volume: get().volume,
            shouldPlay: true
          }
        );
        
        set({ 
          currentSoundId: id, 
          isPlaying: true,
          sound: newSound
        });
      } catch (error) {
        console.error('Error playing sound:', error);
      }
    },
    
    // Toggle play/pause
    togglePlay: async () => {
      const { isPlaying, sound } = get();
      
      if (!sound) return;
      
      try {
        if (isPlaying) {
          await sound.pauseAsync();
        } else {
          await sound.playAsync();
        }
        
        set({ isPlaying: !isPlaying });
      } catch (error) {
        console.error('Error toggling play state:', error);
      }
    },
    
    // Set playing state
    setPlaying: async (isPlaying: boolean) => {
      const { sound } = get();
      
      if (!sound) return;
      
      try {
        if (isPlaying) {
          await sound.playAsync();
        } else {
          await sound.pauseAsync();
        }
        
        set({ isPlaying });
      } catch (error) {
        console.error('Error setting play state:', error);
      }
    },
    
    // Set volume
    setVolume: async (volume: number) => {
      const { sound } = get();
      
      set({ volume });
      
      if (!sound) return;
      
      try {
        await sound.setVolumeAsync(volume);
      } catch (error) {
        console.error('Error setting volume:', error);
      }
    },
    
    // Play completion sound
    playCompletionSound: async (soundId: string) => {
      if (soundId === 'none') return;
      
      try {
        // Find the sound in our list
        const soundData = COMPLETION_SOUNDS.find(s => s.id === soundId);
        if (!soundData || !soundData.url) {
          console.warn(`Completion sound with ID ${soundId} not found or has no URL`);
          return;
        }
        
        console.log(`Playing completion sound: ${soundData.url}`);
        // Create a new sound instance for the completion sound
        const { sound } = await Audio.Sound.createAsync(
          { uri: soundData.url },
          { volume: get().volume }
        );
        
        // Play the sound
        await sound.playAsync();
        
        // Set up a listener to unload the sound when it finishes
        sound.setOnPlaybackStatusUpdate(status => {
          if (status.didJustFinish) {
            sound.unloadAsync();
          }
        });
      } catch (error) {
        console.error('Error playing completion sound:', error);
      }
    },
  };
});

export default useAudioStore;