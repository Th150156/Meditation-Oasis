import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppSettings } from '@/types/meditation';
import { scheduleDailyReminder, cancelAllScheduledNotifications } from '@/services/NotificationService';
import { Platform } from 'react-native';

interface SettingsState {
  settings: AppSettings;
  reminderTime: {
    hour: number;
    minute: number;
  };
  updateSettings: (settings: Partial<AppSettings>) => void;
  setReminderTime: (hour: number, minute: number) => void;
  toggleNotifications: (enabled: boolean) => void;
  toggleDarkMode: (enabled: boolean) => void;
  resetSettings: () => void;
}

const defaultSettings: AppSettings = {
  notificationsEnabled: false,
  darkMode: false,
  soundEffectsEnabled: true,
  completionSoundId: 'bell',
};

const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      settings: defaultSettings,
      reminderTime: {
        hour: 9, // Default to 9:00 AM
        minute: 0,
      },
      
      updateSettings: (newSettings: Partial<AppSettings>) => {
        set((state) => ({
          settings: {
            ...state.settings,
            ...newSettings,
          },
        }));
      },
      
      setReminderTime: async (hour: number, minute: number) => {
        set({ reminderTime: { hour, minute } });
        
        // If notifications are enabled, reschedule with new time
        const { settings } = get();
        if (settings.notificationsEnabled && Platform.OS !== 'web') {
          await scheduleDailyReminder(hour, minute);
        }
      },
      
      toggleNotifications: async (enabled: boolean) => {
        set((state) => ({
          settings: {
            ...state.settings,
            notificationsEnabled: enabled,
          },
        }));
        
        if (Platform.OS !== 'web') {
          if (enabled) {
            // Schedule notification with current reminder time
            const { reminderTime } = get();
            await scheduleDailyReminder(reminderTime.hour, reminderTime.minute);
          } else {
            // Cancel all scheduled notifications
            await cancelAllScheduledNotifications();
          }
        }
      },
      
      toggleDarkMode: (enabled: boolean) => {
        set((state) => ({
          settings: {
            ...state.settings,
            darkMode: enabled,
          },
        }));
      },
      
      resetSettings: async () => {
        set({ 
          settings: defaultSettings,
          reminderTime: {
            hour: 9,
            minute: 0,
          },
        });
        
        if (Platform.OS !== 'web') {
          // Cancel all scheduled notifications
          await cancelAllScheduledNotifications();
        }
      },
    }),
    {
      name: 'settings-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

export default useSettingsStore;