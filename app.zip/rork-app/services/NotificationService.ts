import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import * as Device from 'expo-device';

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Request notification permissions
export const requestNotificationPermissions = async () => {
  if (Platform.OS === 'web') {
    console.log('Notifications not supported on web');
    return false;
  }

  if (Device.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      console.log('Failed to get notification permissions');
      return false;
    }
    
    return true;
  } else {
    console.log('Notifications only work on physical devices');
    return false;
  }
};

// Schedule a daily reminder notification
export const scheduleDailyReminder = async (hour: number, minute: number) => {
  if (Platform.OS === 'web') {
    console.log('Notifications not supported on web');
    return null;
  }

  try {
    // Cancel any existing reminders
    await cancelAllScheduledNotifications();
    
    // Schedule the new reminder
    const identifier = await Notifications.scheduleNotificationAsync({
      content: {
        title: "Time to Meditate",
        body: "Take a few minutes to find your inner peace today.",
        sound: true,
        priority: Notifications.AndroidNotificationPriority.HIGH,
      },
      trigger: {
        hour,
        minute,
        repeats: true,
      },
    });
    
    console.log('Scheduled notification:', identifier);
    return identifier;
  } catch (error) {
    console.error('Error scheduling notification:', error);
    return null;
  }
};

// Cancel all scheduled notifications
export const cancelAllScheduledNotifications = async () => {
  if (Platform.OS === 'web') {
    console.log('Notifications not supported on web');
    return;
  }

  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    console.log('All scheduled notifications canceled');
  } catch (error) {
    console.error('Error canceling notifications:', error);
  }
};

// Get all scheduled notifications
export const getAllScheduledNotifications = async () => {
  if (Platform.OS === 'web') {
    console.log('Notifications not supported on web');
    return [];
  }

  try {
    return await Notifications.getAllScheduledNotificationsAsync();
  } catch (error) {
    console.error('Error getting scheduled notifications:', error);
    return [];
  }
};

// Send an immediate notification
export const sendImmediateNotification = async (title: string, body: string) => {
  if (Platform.OS === 'web') {
    console.log('Notifications not supported on web');
    return null;
  }

  try {
    const identifier = await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: true,
      },
      trigger: null, // Immediate notification
    });
    
    return identifier;
  } catch (error) {
    console.error('Error sending immediate notification:', error);
    return null;
  }
};