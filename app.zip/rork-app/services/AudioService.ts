import { Audio } from 'expo-av';
import { AMBIENT_SOUNDS, COMPLETION_SOUNDS } from '@/constants/sounds';

// Load and play an ambient sound
export const playAmbientSound = async (
  soundId: string, 
  volume: number = 0.7
): Promise<Audio.Sound | null> => {
  try {
    if (soundId === 'none') {
      return null;
    }

    // Find the sound in our list
    const soundData = AMBIENT_SOUNDS.find(s => s.id === soundId);
    if (!soundData || !soundData.url) {
      console.warn(`Sound with ID ${soundId} not found or has no URL`);
      return null;
    }
    
    // Load and play the sound
    console.log(`Attempting to play sound: ${soundData.url}`);
    const { sound } = await Audio.Sound.createAsync(
      { uri: soundData.url },
      { 
        isLooping: true,
        volume: volume,
        shouldPlay: true
      }
    );
    
    return sound;
  } catch (error) {
    console.error('Error playing ambient sound:', error);
    return null;
  }
};

// Play a completion sound
export const playCompletionSound = async (
  soundId: string,
  volume: number = 0.7
): Promise<void> => {
  try {
    if (soundId === 'none') return;
    
    // Find the sound in our list
    const soundData = COMPLETION_SOUNDS.find(s => s.id === soundId);
    if (!soundData || !soundData.url) {
      console.warn(`Completion sound with ID ${soundId} not found or has no URL`);
      return;
    }
    
    console.log(`Attempting to play completion sound: ${soundData.url}`);
    // Create a new sound instance for the completion sound
    const { sound } = await Audio.Sound.createAsync(
      { uri: soundData.url },
      { volume: volume }
    );
    
    // Play the sound
    await sound.playAsync();
    
    // Set up a listener to unload the sound when it finishes
    sound.setOnPlaybackStatusUpdate(status => {
      if (status.didJustFinish) {
        sound.unloadAsync();
      }
    });
  } catch (error) {
    console.error('Error playing completion sound:', error);
  }
};

// Initialize audio system
export const initializeAudio = async (): Promise<boolean> => {
  try {
    // Set up audio mode
    await Audio.setAudioModeAsync({
      playsInSilentModeIOS: true,
      staysActiveInBackground: true,
      shouldDuckAndroid: true,
    });
    
    return true;
  } catch (error) {
    console.error('Error initializing audio:', error);
    return false;
  }
};