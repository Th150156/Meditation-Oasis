import Colors from './colors';
import { Meditation, Sound } from '@/types/meditation';

export const MEDITATIONS: Meditation[] = [
  {
    id: '1',
    title: 'Mindful Breathing',
    description: 'Focus on your breath to calm your mind and body',
    duration: 5,
    color: Colors.primary,
    icon: 'wind',
  },
  {
    id: '2',
    title: 'Body Scan',
    description: 'Bring awareness to each part of your body',
    duration: 10,
    color: Colors.secondary,
    icon: 'scan-face',
  },
  {
    id: '3',
    title: 'Loving Kindness',
    description: 'Cultivate compassion for yourself and others',
    duration: 15,
    color: Colors.accent,
    icon: 'heart',
  },
  {
    id: '4',
    title: 'Stress Relief',
    description: 'Release tension and find calm in the present moment',
    duration: 8,
    color: '#9C27B0',
    icon: 'cloud',
  },
  {
    id: '5',
    title: 'Sleep Better',
    description: 'Prepare your mind and body for restful sleep',
    duration: 20,
    color: '#3F51B5',
    icon: 'moon',
  },
  {
    id: '6',
    title: 'Quick Reset',
    description: 'A brief meditation to reset your mind',
    duration: 3,
    color: '#009688',
    icon: 'refresh-ccw',
  },
];

export const AMBIENT_SOUNDS: Sound[] = [
  {
    id: 'none',
    title: 'None',
    icon: 'volume-x',
  },
  {
    id: 'rain',
    title: 'Rain',
    icon: 'cloud-rain',
  },
  {
    id: 'forest',
    title: 'Forest',
    icon: 'trees',
  },
  {
    id: 'waves',
    title: 'Ocean Waves',
    icon: 'waves',
  },
  {
    id: 'fire',
    title: 'Campfire',
    icon: 'flame',
  },
  {
    id: 'white-noise',
    title: 'White Noise',
    icon: 'radio',
  },
];