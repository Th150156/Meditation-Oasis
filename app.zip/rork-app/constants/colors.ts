import { Theme } from '@/types/meditation';

export const LightTheme: Theme = {
  primary: '#FF6B6B',
  secondary: '#4ECDC4',
  accent: '#FFE66D',
  background: '#F7F7F7',
  white: '#FFFFFF',
  text: '#1A1A1A',
  darkGray: '#666666',
  lightGray: '#E5E5E5',
  border: '#000000',
  error: '#FF4D4D',
  success: '#4CAF50',
};

export const DarkTheme: Theme = {
  primary: '#FF6B6B',
  secondary: '#4ECDC4',
  accent: '#FFE66D',
  background: '#121212',
  white: '#1E1E1E',
  text: '#F5F5F5',
  darkGray: '#BBBBBB',
  lightGray: '#333333',
  border: '#444444',
  error: '#FF4D4D',
  success: '#4CAF50',
};

// Default export for backward compatibility
export default LightTheme;