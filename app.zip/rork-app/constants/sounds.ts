import { Sound } from '@/types/meditation';

export const AMBIENT_SOUNDS: Sound[] = [
  {
    id: 'none',
    title: 'None',
    icon: 'VolumeX',
    url: null,
  },
  {
    id: 'rain',
    title: 'Rain',
    icon: 'CloudRain',
    url: 'https://soundbible.com/mp3/rain_thunder-Mike_Koenig-739472261.mp3',
  },
  {
    id: 'forest',
    title: 'Forest',
    icon: 'Trees',
    url: 'https://soundbible.com/mp3/forest_ambience-GlorySunz-1222731152.mp3',
  },
  {
    id: 'waves',
    title: 'Ocean Waves',
    icon: 'Waves',
    url: 'https://soundbible.com/mp3/Ocean_Waves-Mike_Koenig-980635569.mp3',
  },
  {
    id: 'fire',
    title: 'Campfire',
    icon: 'Flame',
    url: 'https://soundbible.com/mp3/Campfire_1-GlorySunz-1388534383.mp3',
  },
  {
    id: 'white-noise',
    title: 'White Noise',
    icon: 'Radio',
    url: 'https://soundbible.com/mp3/White_Noise_TV_Static-SoundBible.com-1698392756.mp3',
  },
  {
    id: 'wind',
    title: 'Wind',
    icon: 'Wind',
    url: 'https://soundbible.com/mp3/wind-Mark_DiAngelo-1940285615.mp3',
  },
  {
    id: 'stream',
    title: 'Stream',
    icon: 'Droplets',
    url: 'https://soundbible.com/mp3/creek-Daniel_Simion-1572623519.mp3',
  },
  {
    id: 'night',
    title: 'Night',
    icon: 'Moon',
    url: 'https://soundbible.com/mp3/Crickets_At_Night-Mike_Koenig-1822569646.mp3',
  },
];

export const COMPLETION_SOUNDS: Sound[] = [
  {
    id: 'bell',
    title: 'Bell',
    icon: 'Bell',
    url: 'https://soundbible.com/mp3/ship_bell-Mike_Koenig-1911209136.mp3',
  },
  {
    id: 'chime',
    title: 'Chime',
    icon: 'Music',
    url: 'https://soundbible.com/mp3/glass_ping-Go445-1207030150.mp3',
  },
  {
    id: 'gong',
    title: 'Gong',
    icon: 'Music2',
    url: 'https://soundbible.com/mp3/gong_1-Mike_Koenig-1371759493.mp3',
  },
  {
    id: 'none',
    title: 'None',
    icon: 'VolumeX',
    url: null,
  },
];