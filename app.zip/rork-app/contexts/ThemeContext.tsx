import React, { createContext, useContext, useEffect } from 'react';
import { useColorScheme } from 'react-native';
import { Theme } from '@/types/meditation';
import { LightTheme, DarkTheme } from '@/constants/colors';
import useSettingsStore from '@/store/settings-store';

interface ThemeContextType {
  theme: Theme;
  isDark: boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: LightTheme,
  isDark: false,
  toggleTheme: () => {},
});

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const colorScheme = useColorScheme();
  const { settings, toggleDarkMode } = useSettingsStore();
  
  // Determine if dark mode should be used
  const isDark = settings.darkMode;
  
  // Get the appropriate theme
  const theme = isDark ? DarkTheme : LightTheme;
  
  // Toggle theme function
  const toggleTheme = () => {
    toggleDarkMode(!isDark);
  };
  
  // Effect to sync with system theme if user hasn't explicitly set a preference
  useEffect(() => {
    // This could be enhanced to follow system theme if desired
  }, [colorScheme]);
  
  return (
    <ThemeContext.Provider value={{ theme, isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};